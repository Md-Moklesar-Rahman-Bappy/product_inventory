<div>
    <!-- When there is no desire, all things are at peace. - Laozi -->
</div><?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['products']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['products']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="table-responsive">
  <table class="table table-hover table-bordered align-middle text-center shadow-sm rounded"
         style="min-width: 1200px; border-radius: 0.5rem; overflow: hidden;">
    <thead style="background: linear-gradient(to right, #00C9FF, #92FE9D); color: white;">
      <tr class="text-uppercase fw-bold" style="height: 60px;">
        <th>SL</th>
        <th>Product</th>
        <th>Brand</th>
        <th>Model</th>
        <th>Category</th>
        <th>Serial No</th>
        <th>Project Serial</th>
        <th>Position</th>
        <th>User Description</th>
        <th>Remarks</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr style="height: 55px; background-color: <?php echo e($loop->even ? '#f9f9f9' : '#ffffff'); ?>;">
          <td class="fw-bold text-primary"><?php echo e($loop->iteration); ?></td>
          <td class="fw-semibold text-dark" title="<?php echo e($product->product_name); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->product_name, 8)); ?>

          </td>
          <td title="<?php echo e($product->brand->brand_name ?? '-'); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->brand->brand_name ?? '-', 8)); ?>

          </td>
          <td title="<?php echo e($product->model->model_name ?? '-'); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->model->model_name ?? '-', 8)); ?>

          </td>
          <td title="<?php echo e($product->category->category_name ?? '-'); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->category->category_name ?? '-', 8)); ?>

          </td>
          <td title="<?php echo e($product->serial_no); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->serial_no, 8)); ?>

          </td>
          <td title="<?php echo e($product->project_serial ?? '-'); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->project_serial ?? '-', 8)); ?>

          </td>
          <td title="<?php echo e($product->position ?? '-'); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->position ?? '-', 8)); ?>

          </td>
          <td title="<?php echo e($product->user_description ?? '-'); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->user_description ?? '-', 8)); ?>

          </td>
          <td title="<?php echo e($product->remarks ?? '-'); ?>">
            <?php echo e(\Illuminate\Support\Str::limit($product->remarks ?? '-', 8)); ?>

          </td>
          <td>
            <div class="d-flex justify-content-center gap-2">
              <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-sm btn-outline-info" title="View">
                <i class="fa fa-eye"></i>
              </a>
              <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-sm btn-outline-warning" title="Edit">
                <i class="fa fa-edit"></i>
              </a>
            </div>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="11" class="text-center py-5 text-muted">
            <div class="d-flex flex-column align-items-center justify-content-center">
              <i class="fa fa-box-open fa-2x mb-3 text-danger"></i>
              <h5 class="fw-bold">No products found</h5>
              <p class="small">Try adding a new product to populate the list.</p>
            </div>
          </td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>


<div class="mt-4">
  <?php echo e($products->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\components\product-table.blade.php ENDPATH**/ ?>