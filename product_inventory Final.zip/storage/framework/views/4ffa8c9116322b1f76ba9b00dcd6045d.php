<?php $__env->startSection('title', 'Home Product'); ?>

<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card border-0 shadow-lg rounded-4 overflow-hidden">

            
            <div class="card-header text-white py-4" style="background: linear-gradient(90deg, #00bcd4, #2196f3);">
                <div class="row align-items-center g-3">
                    
                    <div class="col-md-4">
                        <h3 class="mb-0 fw-bold">
                            <i class="fa fa-boxes me-2"></i> Product Inventory
                            <span class="badge bg-light text-dark ms-3"><?php echo e($products->total()); ?> items</span>
                        </h3>
                    </div>

                    
                    <div class="col-md-4">
                        <form method="GET" action="<?php echo e(route('products.index')); ?>" class="d-flex justify-content-center">
                            <div class="input-group" style="max-width: 400px; width: 100%;">
                                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                                    class="form-control bg-light border-0 small" placeholder="Search by Serial Number" aria-label="Search by Serial Number">
                                <button class="btn btn-primary" type="submit" aria-label="Search">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </form>
                    </div>

                    
                    <div class="col-md-4 text-end">
                        <?php if(auth()->user()->permission <= 1): ?>
                            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-warning fw-bold shadow-sm me-2">
                                <i class="fa fa-plus me-1"></i> Add Product
                            </a>
                            <a href="<?php echo e(route('products.export.excel')); ?>" class="btn btn-info">
                                📤 Export All
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="card-body bg-light p-4">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show shadow-sm fw-semibold" role="alert">
                        <i class="fa fa-check-circle me-1"></i> <?php echo e(Session::get('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle text-center shadow-sm product-table">
                        <thead class="text-uppercase fw-bold text-primary" style="background-color: #e3f2fd;">
                            <tr>
                                <th style="width: 50px;">SL</th>
                                <th style="min-width: 80px;">Product</th>
                                <th style="min-width: 90px;">Price</th>

                                
                                <th style="min-width: 90px;">Serial No</th>
                                <th class="d-none-xs" style="min-width: 80px;">Project Serial</th>
                                <th class="d-none-xs" style="min-width: 70px;">Location</th>
                                <th class="d-none-md" style="min-width: 100px;">User Description</th>
                                <th class="d-none-sm" style="min-width: 80px;">Remarks</th>
                                <th style="min-width: 90px;">Warranty</th>
                                <th style="min-width: 120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-bold text-primary">
                                    <?php echo e(($products->currentPage() - 1) * $products->perPage() + $loop->iteration); ?>

                                </td>
                                <td class="fw-semibold text-dark tooltip-cell" title="<?php echo e($p->product_name); ?>">
                                    <?php echo e($p->product_name); ?>

                                </td>
                                <td><?php echo e(number_format($p->price, 2)); ?> ৳</td>
                                
                                <td class="tooltip-cell" title="<?php echo e($p->serial_no); ?>">
                                    <?php if(request('search')): ?>
                                        <?php echo str_replace(request('search'), '<mark>' . e(request('search')) . '</mark>', e($p->serial_no)); ?>

                                    <?php else: ?>
                                        <?php echo e($p->serial_no ?? '-'); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="d-none-xs tooltip-cell" title="<?php echo e($p->project_serial_no); ?>">
                                    <?php echo e($p->project_serial_no ?? '-'); ?>

                                </td>
                                <td class="d-none-xs tooltip-cell" title="<?php echo e($p->position); ?>">
                                    <?php echo e($p->position ?? '-'); ?>

                                </td>
                                <td class="d-none-md tooltip-cell" title="<?php echo e($p->user_description); ?>">
                                    <?php echo e($p->user_description ?? '-'); ?>

                                </td>
                                <td class="d-none-sm tooltip-cell" title="<?php echo e($p->remarks); ?>">
                                    <?php echo e($p->remarks ?? '-'); ?>

                                </td>
                                <td><?php echo $p->warranty_countdown; ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="<?php echo e(route('products.show', $p->id)); ?>" class="btn btn-sm btn-outline-info" title="View">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                        <?php if(auth()->user()->permission <= 1): ?>
                                            <a href="<?php echo e(route('products.edit', $p->id)); ?>" class="btn btn-sm btn-outline-warning" title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('products.destroy', $p->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                            <a href="<?php echo e(route('maintenance.create', ['product_id' => $p->id])); ?>"
                                                class="btn btn-sm btn-outline-primary" title="Send to Maintenance">
                                                <i class="fa fa-tools me-1"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="12" class="text-center py-5 text-muted">
                                    <div class="d-flex flex-column align-items-center justify-content-center">
                                        <img src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png" alt="No products" width="100" class="mb-3 opacity-75">
                                        <h5 class="fw-bold text-danger">No products found</h5>
                                        <p class="small">Start by adding a new product to your inventory.</p>
                                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-outline-primary btn-lg fw-bold">
                                            <i class="fa fa-plus me-1"></i> Add Product
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if (isset($component)) { $__componentOriginal3e6684d352797b6b0d491487a3c7f550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e6684d352797b6b0d491487a3c7f550 = $attributes; } ?>
<?php $component = App\View\Components\PaginationBlock::resolve(['paginator' => $products] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PaginationBlock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $attributes = $__attributesOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $component = $__componentOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__componentOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>

                <!-- Recycle Bin Section -->
                <?php if(\App\Models\Product::onlyTrashed()->count() > 0): ?>
                <div class="mt-4">
                    <h5 class="text-danger">🗑️ Recycle Bin</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered product-table">
                            <thead class="bg-light">
                                <tr>
                                    <th>Product Name</th>
                                    <th>Serial No</th>
                                    <th class="d-none-sm">Deleted At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = \App\Models\Product::onlyTrashed()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="tooltip-cell" title="<?php echo e($deleted->product_name); ?>">
                                        <?php echo e(Str::limit($deleted->product_name, 15, '...')); ?>

                                    </td>
                                    <td><?php echo e($deleted->serial_no); ?></td>
                                    <td class="d-none-sm"><?php echo e($deleted->deleted_at->format('d M Y, h:i A')); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('products.restore', $deleted->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-success" title="Restore Product">
                                                <i class="fa fa-undo"></i> Restore
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/products/index.blade.php ENDPATH**/ ?>