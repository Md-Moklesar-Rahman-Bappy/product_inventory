<?php $__env->startSection('title', 'Maintenance Details'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container py-5">
  <div class="card border-0 shadow-lg rounded-4">
    <div class="card-header bg-info text-white py-3">
      <h3 class="mb-0 fw-bold">
        <i class="fa fa-wrench me-2"></i> Maintenance #<?php echo e($maintenance->id); ?>

      </h3>
    </div>

    <div class="card-body bg-light px-4 py-5">
      <div class="row mb-4">
        <div class="col-md-6">
          <h5 class="fw-bold text-primary">🔧 Product Info</h5>
          <p><strong>Name:</strong> <?php echo e($maintenance->product->product_name); ?></p>
          <p><strong>Serial No:</strong> <?php echo e($maintenance->product->serial_no); ?></p>
        </div>
        <div class="col-md-6">
          <h5 class="fw-bold text-primary">🛠️ Maintenance Details</h5>
          <p><strong>Issue:</strong> <?php echo e($maintenance->description); ?></p>
          <p><strong>Start:</strong> <?php echo e($maintenance->start_time->format('d M Y, h:i A')); ?></p>
          <p><strong>End:</strong> <?php echo e($maintenance->end_time->format('d M Y, h:i A')); ?></p>
          <p><strong>Status:</strong>
            <?php if(now()->between($maintenance->start_time, $maintenance->end_time)): ?>
              <span class="badge bg-warning text-dark">In Progress</span>
            <?php elseif(now()->lt($maintenance->start_time)): ?>
              <span class="badge bg-info text-dark">Scheduled</span>
            <?php else: ?>
              <span class="badge bg-success">Completed</span>
            <?php endif; ?>
          </p>
        </div>
      </div>

      <div class="mb-4">
        <h5 class="fw-bold text-primary">👤 Logged By</h5>
        <p><?php echo e($maintenance->user->name ?? 'System'); ?></p>
      </div>

      <div class="d-flex justify-content-between">
        <?php if(auth()->user()->permission <= 1): ?>
          <a href="<?php echo e(route('maintenance.edit', $maintenance->id)); ?>" class="btn btn-sm btn-outline-warning">
            <i class="fa fa-edit me-1"></i> Edit
          </a>

          <form action="<?php echo e(route('maintenance.destroy', $maintenance->id)); ?>" method="POST" onsubmit="return confirm('Delete this record?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-outline-danger">
              <i class="fa fa-trash me-1"></i> Delete
            </button>
          </form>
        <?php endif; ?>

        <a href="<?php echo e(route('maintenance.index')); ?>" class="btn btn-secondary">
          <i class="fa fa-arrow-left me-1"></i> Back to List
        </a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\maintenance\show.blade.php ENDPATH**/ ?>