<?php $__env->startSection('title', 'Create User'); ?>

<?php $__env->startSection('contents'); ?>

<div class="app-content main-content mt-0">
    <div class="side-app">
        <div class="main-container container-fluid">

            <!-- PAGE HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">
                        <i class="fa fa-user-plus me-2 text-primary"></i> Create User Form
                    </h1>
                </div>
                <div class="ms-auto pageheader-btn">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Create User</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Form Layouts</li>
                    </ol>
                </div>
            </div>

            <!-- FORM ROW -->
            <div class="row row-deck">
                <div class="col-lg-8 offset-lg-2 col-md-8">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-header bg-gradient-info text-white text-center py-3">
                            <h3 class="card-title fw-bold"><i class="fa fa-user-edit me-2"></i> Create User</h3>
                        </div>
                        <div class="card-body bg-light p-4">

                            <?php if(session('message')): ?>
                                <div class="alert alert-success text-center fw-semibold">
                                    <i class="fa fa-check-circle me-1"></i> <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger shadow-sm">
                                    <ul class="mb-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><i class="fa fa-exclamation-circle me-1 text-danger"></i> <?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <form class="form-horizontal" action="<?php echo e(route('users.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                
                                <div class="row mb-4">
                                    <label for="name" class="col-md-3 form-label">User Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="name" name="name" class="form-control"
                                               placeholder="User Name" value="<?php echo e(old('name')); ?>" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label for="email" class="col-md-3 form-label">Email</label>
                                    <div class="col-md-9">
                                        <input type="email" id="email" name="email" class="form-control"
                                               placeholder="User Email" value="<?php echo e(old('email')); ?>" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label for="mobile" class="col-md-3 form-label">Mobile Number</label>
                                    <div class="col-md-9">
                                        <input type="text" id="mobile" name="mobile" class="form-control"
                                               placeholder="User Mobile No" value="<?php echo e(old('mobile')); ?>">
                                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label for="permission" class="col-md-3 form-label">Permission</label>
                                    <div class="col-md-9">
                                        <select name="permission" id="permission" class="form-control" required>
                                            <option disabled <?php echo e(old('permission') ? '' : 'selected'); ?>>Select user type</option>
                                            <option value="1" <?php echo e(old('permission') == 1 ? 'selected' : ''); ?>>Admin</option>
                                            <option value="2" <?php echo e(old('permission') == 2 ? 'selected' : ''); ?>>User</option>
                                        </select>
                                        <?php $__errorArgs = ['permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label for="designation" class="col-md-3 form-label">Designation</label>
                                    <div class="col-md-9">
                                        <input type="text" id="designation" name="designation" class="form-control"
                                               placeholder="User designation" value="<?php echo e(old('designation')); ?>">
                                        <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label for="profile_photo_path" class="col-md-3 form-label">User Photo</label>
                                    <div class="col-md-9">
                                        <input type="file" id="profile_photo_path" name="profile_photo_path"
                                               class="dropify form-control" data-height="200"
                                               data-default-file="<?php echo e(asset('images/default-user.png')); ?>">
                                        <?php $__errorArgs = ['profile_photo_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label for="about" class="col-md-3 form-label">About</label>
                                    <div class="col-md-9">
                                        <textarea id="about" name="about" class="form-control" rows="3"><?php echo e(old('about')); ?></textarea>
                                        <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label for="address" class="col-md-3 form-label">Address</label>
                                    <div class="col-md-9">
                                        <textarea id="address" name="address" class="form-control" rows="3"><?php echo e(old('address')); ?></textarea>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label for="password" class="col-md-3 form-label">Password</label>
                                    <div class="col-md-9">
                                        <input type="password" id="password" name="password" class="form-control"
                                               placeholder="User Password" autocomplete="off" required>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="row mb-4">
                                    <label class="col-md-3 form-label"></label>
                                    <div class="col-md-9">
                                        <button type="submit" class="btn btn-primary fw-bold">
                                            <i class="fa fa-check me-1"></i> Create User
                                        </button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!-- END ROW -->

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/dropify/css/dropify.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/plugins/dropify/js/dropify.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $('.dropify').dropify({
            messages: {
                'default': 'Drag and drop a file here or click',
                'replace': 'Drag and drop or click to replace',
                'remove':  'Remove',
                'error':   'Ooops, something wrong happened.'
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/users/create.blade.php ENDPATH**/ ?>