<?php $__env->startSection('title', 'User Details'); ?>

<?php $__env->startSection('contents'); ?>

<div class="app-content main-content mt-0">
    <div class="side-app">
        <div class="main-container container-fluid">

            <!-- PAGE HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">
                        <i class="fa fa-user-circle me-2 text-primary"></i> User Details
                    </h1>
                </div>
                <div class="ms-auto pageheader-btn">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Details</li>
                    </ol>
                </div>
            </div>

            <!-- USER CARD -->
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-header bg-gradient-info text-white text-center py-3">
                            <h3 class="card-title fw-bold"><i class="fa fa-id-badge me-2"></i> User Profile</h3>
                        </div>
                        <div class="card-body bg-light p-4">
                            <div class="text-center mb-4">
                                <img src="<?php echo e($user->profile_photo_url); ?>"
                                    alt="Profile Photo" class="rounded-circle shadow-sm" width="120" height="120" style="object-fit: cover;">
                                <h4 class="mt-3 mb-1 fw-bold"><?php echo e($user->name); ?></h4>
                                <span class="badge bg-info text-white"><?php echo e($user->role_label); ?></span>
                                <span class="badge <?php echo e($user->deleted_at ? 'bg-danger' : 'bg-success'); ?> ms-2 text-white">
                                    <?php echo e($user->deleted_at ? 'Deleted' : 'Active'); ?>

                                </span>
                            </div>

                            <table class="table table-bordered table-hover shadow-sm">
                                <tr>
                                    <th class="bg-light text-primary">Email</th>
                                    <td><?php echo e($user->email); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-primary">Mobile</th>
                                    <td><?php echo $user->mobile_display ?? '<span class="text-muted">—</span>'; ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-primary">Designation</th>
                                    <td><?php echo $user->designation_display ?? '<span class="text-muted">—</span>'; ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-primary">About</th>
                                    <td><?php echo $user->about ? e($user->about) : '<span class="text-muted">—</span>'; ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-primary">Address</th>
                                    <td><?php echo $user->address ? e($user->address) : '<span class="text-muted">—</span>'; ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-primary">Created At</th>
                                    <td><?php echo e($user->created_at->format('d M Y, h:i A')); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-primary">Updated At</th>
                                    <td><?php echo e($user->updated_at->format('d M Y, h:i A')); ?></td>
                                </tr>
                            </table>

                            <div class="text-end mt-4">
                                <?php if(auth()->id() === $user->id || auth()->user()->permission <= 1): ?>
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning fw-bold">
                                        <i class="fa fa-edit me-1"></i> Edit
                                    </a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary fw-bold">
                                    <i class="fa fa-arrow-left me-1"></i> Back to List
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END ROW -->

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\users\show.blade.php ENDPATH**/ ?>