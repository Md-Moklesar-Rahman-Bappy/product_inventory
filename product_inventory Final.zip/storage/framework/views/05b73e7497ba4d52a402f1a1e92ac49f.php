<?php $__env->startSection('title', 'Verify Your Email'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container py-5">
    <div class="text-center">
        <h3 class="text-primary fw-bold">📧 Email Verification Required</h3>
        <p class="text-muted">Please check your inbox and click the verification link to activate your account.</p>

        <?php if(session('message')): ?>
            <div class="alert alert-success mt-3">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('verification.resend')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-primary mt-3">
                Resend Verification Email
            </button>
        </form>

        <p class="text-muted mt-4">Didn’t receive the email? Check your spam folder or click above to resend.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/auth/verify.blade.php ENDPATH**/ ?>