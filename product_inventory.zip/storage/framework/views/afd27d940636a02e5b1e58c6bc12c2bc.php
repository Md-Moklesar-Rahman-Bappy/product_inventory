<?php $__env->startSection('title', 'Show Category'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container py-5">
  <div class="card border-0 shadow-lg rounded-4 overflow-hidden">

    
    <div class="card-header text-white" style="background: linear-gradient(90deg, #4CAF50, #81C784); padding: 1.5rem;">
      <h3 class="mb-0 fw-bold"><i class="fa fa-info-circle me-2"></i> Category Details</h3>
    </div>

    
    <div class="card-body bg-light" style="padding: 2rem;">
      <div class="row mb-4">
        <div class="col-md-6 mb-3">
          <label class="form-label fw-semibold text-dark">Category Name</label>
          <input type="text" class="form-control form-control-lg shadow-sm" value="<?php echo e($category->category_name); ?>" readonly>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label fw-semibold text-dark">Created At</label>
          <input type="text" class="form-control shadow-sm" value="<?php echo e($category->created_at->format('d M Y, h:i A')); ?>" readonly>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label fw-semibold text-dark">Updated At</label>
          <input type="text" class="form-control shadow-sm" value="<?php echo e($category->updated_at->format('d M Y, h:i A')); ?>" readonly>
        </div>
      </div>

      
      <div class="mt-4">
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-gradient fw-bold">
          <i class="fa fa-arrow-left me-1"></i> Back to Category List
        </a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\categories\show.blade.php ENDPATH**/ ?>