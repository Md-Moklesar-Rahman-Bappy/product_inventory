<?php $__env->startSection('title', 'Show Product'); ?>

<?php $__env->startSection('contents'); ?>
  <div class="container py-4">
    <div class="card shadow-sm">
      <div class="card-header bg-info text-white">
        <h4 class="mb-0"><i class="fa fa-box-open me-2"></i> Product Details</h4>
      </div>

      <div class="card-body">
        
        <h5 class="text-secondary mb-3">📦 Product Info</h5>

        <div class="row mb-3">
          <div class="col-md-6">
            <label class="form-label">Product Name</label>
            <input type="text" class="form-control" value="<?php echo e($product->product_name); ?>" readonly title="<?php echo e($product->product_name); ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Price (৳)</label>
            <input type="text" class="form-control" value="<?php echo e(number_format($product->price, 2)); ?>" readonly title="<?php echo e($product->price); ?>">
            <?php if($product->price > 1000000): ?>
              <span class="badge bg-danger text-light mt-2">💸 High Value</span>
            <?php elseif($product->price < 500000): ?>
              <span class="badge bg-success mt-2">🔖 Budget Pick</span>
            <?php endif; ?>
          </div>
        </div>

        
        <div class="row mb-3">
          <div class="col-md-4">
            <label class="form-label">Category</label>
            <input type="text" class="form-control" value="<?php echo e($product->category?->category_name ?? 'N/A'); ?>" readonly title="<?php echo e($product->category?->category_name); ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label">Brand</label>
            <input type="text" class="form-control" value="<?php echo e($product->brand?->brand_name ?? 'N/A'); ?>" readonly title="<?php echo e($product->brand?->brand_name); ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label">Model</label>
            <input type="text" class="form-control" value="<?php echo e($product->model?->model_name ?? 'N/A'); ?>" readonly title="<?php echo e($product->model?->model_name); ?>">
          </div>
        </div>

        
        <h5 class="text-secondary mb-3">🔢 Serial Numbers</h5>
        <div class="row mb-3">
          <div class="col-md-6">
            <label class="form-label">Serial No</label>
            <input type="text" class="form-control" value="<?php echo e($product->serial_no ?? '-'); ?>" readonly title="<?php echo e($product->serial_no); ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Project Serial No</label>
            <input type="text" class="form-control" value="<?php echo e($product->project_serial_no ?? '-'); ?>" readonly title="<?php echo e($product->project_serial_no); ?>">
          </div>
        </div>

        
        <h5 class="text-secondary mb-3">📍 Location & Description</h5>
        <div class="row mb-3">
          <div class="col-md-6">
            <label class="form-label">Location</label>
            <input type="text" class="form-control" value="<?php echo e($product->position ?? '-'); ?>" readonly title="<?php echo e($product->position); ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">User Description</label>
            <textarea class="form-control" rows="3" readonly title="<?php echo e($product->user_description); ?>"><?php echo e($product->user_description ?? '-'); ?></textarea>
          </div>
        </div>

        
        <h5 class="text-secondary mb-3">📝 Remarks</h5>
        <div class="mb-3">
          <label class="form-label">Remarks</label>
          <textarea class="form-control" rows="3" readonly title="<?php echo e($product->remarks); ?>"><?php echo e($product->remarks ?? '-'); ?></textarea>
        </div>

        
        
        
        <h5 class="text-secondary mb-3">🛡️ Warranty Status</h5>
        <div class="row mb-3">
        <div class="col-md-6">
            <label class="form-label">Warranty Start</label>
            <input type="text" class="form-control"
                value="<?php echo e($product->warranty_start?->format('Y-m-d') ?? '-'); ?>" readonly>
        </div>
        <div class="col-md-6">
            <label class="form-label">Warranty End</label>
            <input type="text" class="form-control"
                value="<?php echo e($product->warranty_end?->format('Y-m-d') ?? '-'); ?>" readonly>
        </div>
        </div>

        <?php
        $now = now();
        $start = $product->warranty_start;
        $end = $product->warranty_end;
        ?>

        <?php if($start && $end): ?>
        <?php if($now->between($start, $end)): ?>
            <div class="alert alert-success shadow-sm">
            <i class="fa fa-check-circle me-1"></i>
            Warranty is active. <strong><?php echo e($end->diffForHumans($now, ['parts' => 2])); ?> remaining</strong>.
            </div>
        <?php elseif($now->lt($start)): ?>
            <div class="alert alert-warning shadow-sm">
            <i class="fa fa-hourglass-start me-1"></i>
            Warranty starts in <strong><?php echo e($start->diffForHumans($now, ['parts' => 2])); ?></strong>.
            </div>
        <?php else: ?>
            <div class="alert alert-danger shadow-sm">
            <i class="fa fa-times-circle me-1"></i>
            Warranty expired <strong><?php echo e($end->diffForHumans($now, ['parts' => 2])); ?></strong> ago.
            </div>
        <?php endif; ?>
        <?php endif; ?>

        
        <h5 class="text-secondary mb-3">📅 Timestamps</h5>
        <div class="row">
          <div class="col-md-6">
            <label class="form-label">Created At</label>
            <input type="text" class="form-control" value="<?php echo e($product->created_at->format('Y-m-d H:i')); ?>" readonly>
          </div>
          <div class="col-md-6">
            <label class="form-label">Updated At</label>
            <input type="text" class="form-control" value="<?php echo e($product->updated_at->format('Y-m-d H:i')); ?>" readonly>
          </div>
        </div>

        
        <div class="mt-4">
          <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
            <i class="fa fa-arrow-left me-1"></i> Go Back
          </a>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\products\show.blade.php ENDPATH**/ ?>