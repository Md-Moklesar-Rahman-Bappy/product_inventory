<?php $__env->startSection('title', 'Activity Log For Product Inventory System'); ?>

<?php $__env->startSection('contents'); ?>
<div class="row">
  <div class="col-md-12">

    <!-- 📜 Activity Logs Card -->
    <div class="card shadow-sm border-0">
      <div class="card-header bg-white border-bottom py-3">
        <div class="row align-items-center">
          <div class="col-md-6 d-flex align-items-center gap-3">
            <h5 class="mb-0 text-info fw-bold">Recent Activity Logs</h5>

            <!-- 🔍 Filter Dropdown -->
            <form method="GET" action="<?php echo e(route('activity.logs')); ?>">
              <select name="model" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Models</option>
                <option value="Product" <?php echo e(request('model') === 'Product' ? 'selected' : ''); ?>>Product</option>
                <option value="Category" <?php echo e(request('model') === 'Category' ? 'selected' : ''); ?>>Category</option>
                <option value="Brand" <?php echo e(request('model') === 'Brand' ? 'selected' : ''); ?>>Brand</option>
                <option value="Model" <?php echo e(request('model') === 'Model' ? 'selected' : ''); ?>>Model</option>
                <option value="Maintenance" <?php echo e(request('model') === 'Maintenance' ? 'selected' : ''); ?>>Maintenance</option>
              </select>
            </form>
          </div>

          <div class="col-md-6 text-end">
            <span class="badge bg-light text-dark"><?php echo e($logs->total()); ?> total logs</span>
          </div>
        </div>
      </div>

      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-bordered table-hover align-middle mb-0">
            <thead class="table-light text-uppercase text-primary small">
              <tr>
                <th>User</th>
                <th>Action</th>
                <th>Model</th>
                <th>Description</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php
                $isNoChange = $log->action === 'update' && Str::contains($log->description, 'No changes');
              ?>
              <tr>
                <td class="fw-semibold text-dark"><?php echo e($log->user->name ?? 'System'); ?></td>
                <td>
                  <span class="badge
                    <?php if($log->action === 'create'): ?> bg-success text-white
                    <?php elseif($isNoChange): ?> bg-secondary text-white
                    <?php elseif($log->action === 'update'): ?> bg-primary text-white
                    <?php elseif($log->action === 'delete'): ?> bg-danger text-white
                    <?php else: ?> bg-secondary text-white <?php endif; ?>">
                    <?php echo e(ucfirst($log->action)); ?>

                  </span>
                </td>
                <td><span class="text-muted"><?php echo e($log->model ?? '-'); ?></span></td>
                <td class="<?php echo e($isNoChange ? 'text-muted fst-italic' : ''); ?>">
                  <?php echo $log->description; ?>

                </td>
                <td>
                  <div class="text-nowrap" title="<?php echo e($log->updated_at->format('Y-m-d H:i:s')); ?>">
                    <strong><?php echo e($log->updated_at->format('d M Y, h:i:s A')); ?></strong><br>
                    <small class="text-muted fst-italic">(<?php echo e($log->updated_at->diffForHumans()); ?>)</small>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="5" class="text-center py-5 text-muted">
                  <div class="d-flex flex-column align-items-center justify-content-center">
                    <img src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png" alt="No logs" width="80" class="mb-3 opacity-75">
                    <h6 class="fw-bold text-danger">No activity logs found</h6>
                    <p class="small">Start interacting with the system to generate logs.</p>
                  </div>
                </td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <!-- 📄 Pagination -->
        <?php if (isset($component)) { $__componentOriginal3e6684d352797b6b0d491487a3c7f550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e6684d352797b6b0d491487a3c7f550 = $attributes; } ?>
<?php $component = App\View\Components\PaginationBlock::resolve(['paginator' => $logs] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PaginationBlock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $attributes = $__attributesOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $component = $__componentOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__componentOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\activity_logs\index.blade.php ENDPATH**/ ?>