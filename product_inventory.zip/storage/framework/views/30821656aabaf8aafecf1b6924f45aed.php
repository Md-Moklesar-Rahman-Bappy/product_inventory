<!DOCTYPE html>
<html lang="en">
<head>
  <title>SOCDS Project Admin - Login</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Assets -->
  <link rel="stylesheet" href="<?php echo e(asset('index/vendor/bootstrap/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('index/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('index/vendor/animate/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('index/vendor/css-hamburgers/hamburgers.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('index/vendor/select2/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('index/css/util.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('index/css/main.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
  <style>
    .container-login100 {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding-top: 0 !important;
    }
    .wrap-login100 {
      padding: 40px 55px;
    }
    .login100-form-title {
      margin-bottom: 25px;
    }
  </style>
</head>
<body>

  <div class="limiter">
    <div class="container-login100">
      <div class="wrap-login100">
        <div class="login100-pic js-tilt" data-tilt>
          <img src="<?php echo e(asset('index/images/img-01.png')); ?>" alt="IMG">
        </div>

        <form class="login100-form validate-form" method="POST" action="<?php echo e(route('login.action')); ?>" novalidate role="form">
          <?php echo csrf_field(); ?>

          <span class="login100-form-title">Project Member Login</span>

          
            <?php $__currentLoopData = ['success', 'error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(session($msg)): ?>
                <div class="alert alert-<?php echo e($msg); ?> w-100 text-center"><?php echo e(session($msg)); ?></div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(session('message')): ?>
                <div class="alert alert-success w-100 text-center">
                    <?php echo session('message'); ?>

                </div>
            <?php endif; ?>

          
          <div class="wrap-input100 validate-input" data-validate="Valid email is required: ex@abc.xyz">
            <input class="input100 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" name="email"
                   value="<?php echo e(old('email')); ?>" placeholder="Email" required autocomplete="email">
            <span class="focus-input100"></span>
            <span class="symbol-input100"><i class="fa fa-envelope" aria-hidden="true"></i></span>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback d-block text-white" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div class="wrap-input100 validate-input" data-validate="Password is required">
            <input id="password" class="input100 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   type="password" name="password" placeholder="Password"
                   required autocomplete="current-password">
            <span class="symbol-input100"><i class="fa fa-lock" aria-hidden="true"></i></span>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback d-block text-white"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div class="container-login100-form-btn">
            <button type="submit" class="login100-form-btn">Login</button>
          </div>

        </form>
      </div>
    </div>
  </div>

  <!-- Custom Script -->
  <script>
    $(document).ready(function () {
      $('.js-tilt').tilt({ scale: 1.1 });

      $('form').on('submit', function () {
        $('.login100-form-btn').prop('disabled', true).text('Logging in...');
      });
    });

    setTimeout(() => {
  $('.alert-success').fadeOut('slow');
}, 5000);

  </script>

  <!-- Scripts -->
  <script src="<?php echo e(asset('index/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('index/vendor/bootstrap/js/popper.js')); ?>"></script>
  <script src="<?php echo e(asset('index/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('index/vendor/select2/select2.min.js')); ?>"></script>
  <script src="<?php echo e(asset('index/vendor/tilt/tilt.jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('index/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/auth/login.blade.php ENDPATH**/ ?>