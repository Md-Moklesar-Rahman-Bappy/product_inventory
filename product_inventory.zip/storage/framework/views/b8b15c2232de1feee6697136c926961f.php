<?php if($paginator->hasPages()): ?>
    <nav class="pagination-block mt-4" aria-label="Pagination Navigation">
        <ul class="pagination justify-content-center flex-wrap gap-2">
            
            <li class="page-item <?php echo e($paginator->onFirstPage() ? 'disabled' : ''); ?>"
                aria-disabled="<?php echo e($paginator->onFirstPage() ? 'true' : 'false'); ?>"
                aria-label="<?php echo e(__('pagination.previous')); ?>">
                <?php if($paginator->onFirstPage()): ?>
                    <span class="page-link" aria-hidden="true">
                        <i class="fas fa-angle-left fa-sm text-muted"></i>
                    </span>
                <?php else: ?>
                    <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">
                        <i class="fas fa-angle-left fa-sm"></i>
                    </a>
                <?php endif; ?>
            </li>

            
            <?php $__currentLoopData = $paginator->links()->elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="page-item <?php echo e($page == $paginator->currentPage() ? 'active' : ''); ?>"
                    aria-current="<?php echo e($page == $paginator->currentPage() ? 'page' : ''); ?>">
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="page-link"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <li class="page-item <?php echo e($paginator->hasMorePages() ? '' : 'disabled'); ?>"
                aria-disabled="<?php echo e($paginator->hasMorePages() ? 'false' : 'true'); ?>"
                aria-label="<?php echo e(__('pagination.next')); ?>">
                <?php if($paginator->hasMorePages()): ?>
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">
                        <i class="fas fa-angle-right fa-sm"></i>
                    </a>
                <?php else: ?>
                    <span class="page-link" aria-hidden="true">
                        <i class="fas fa-angle-right fa-sm text-muted"></i>
                    </span>
                <?php endif; ?>
            </li>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/components/pagination-block.blade.php ENDPATH**/ ?>