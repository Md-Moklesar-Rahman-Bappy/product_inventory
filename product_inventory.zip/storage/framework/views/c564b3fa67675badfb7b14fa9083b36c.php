<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>
                <strong>© July 2020 – <?php echo e(date('d M Y, h:i:s A')); ?> DLRS SOCDS Project</strong>
            </span>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/layouts/footer.blade.php ENDPATH**/ ?>