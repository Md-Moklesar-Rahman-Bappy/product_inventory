<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>
                <strong>© July 2020 – {{ date('d M Y, h:i:s A') }} DLRS SOCDS Project</strong>
            </span>
        </div>
    </div>
</footer>
