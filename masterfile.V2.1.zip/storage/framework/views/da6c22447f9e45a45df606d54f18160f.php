<?php $__env->startSection('title', 'Warranty Overview'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container py-5">
  <div class="card border-0 shadow-lg rounded-4">
    <div class="card-header bg-primary text-white py-3">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h3 class="mb-0 fw-bold">
          <i class="fa fa-shield-alt me-2"></i> Product Warranties
        </h3>

        <form method="GET" class="d-flex align-items-center gap-2">
          <select name="warranty_status" class="form-select w-auto">
            <option value="">All</option>
            <option value="active" <?php echo e(request('warranty_status') === 'active' ? 'selected' : ''); ?>>Active</option>
            <option value="expired" <?php echo e(request('warranty_status') === 'expired' ? 'selected' : ''); ?>>Expired</option>
          </select>
          <button type="submit" class="btn btn-light">Filter</button>
        </form>
      </div>
    </div>

    <div class="card-body bg-light px-4 py-5">
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center shadow-sm">
          <thead class="bg-light text-uppercase fw-bold text-primary">
            <tr>
              <th scope="col">SL</th>
              <th scope="col">Product Name</th>
              <th scope="col">Serial No</th>
              <th scope="col">Project Serial</th>
              <th scope="col">Warranty Ends</th>
              <th scope="col">Countdown</th>
            </tr>
          </thead>
          <tbody>
            <?php $lastUrgency = null; ?>

            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php
                $urgency = $p->urgency_level;
                $now = \Carbon\Carbon::now();
                $end = \Carbon\Carbon::parse($p->warranty_end);
                $expired = $p->warranty_end && $end->isPast();
              ?>

              
              <?php if($urgency !== $lastUrgency): ?>
                <tr>
                  <td colspan="6" class="bg-secondary text-white fw-bold text-start px-3">
                    <?php switch($urgency):
                      case (0): ?> Expired Warranties <?php break; ?>
                      <?php case (1): ?> Expiring in 7 Days <?php break; ?>
                      <?php case (2): ?> Expiring in 30 Days <?php break; ?>
                      <?php case (3): ?> Active Warranties <?php break; ?>
                      <?php case (4): ?> No Warranty Info <?php break; ?>
                      <?php default: ?> Unknown
                    <?php endswitch; ?>
                  </td>
                </tr>
                <?php $lastUrgency = $urgency; ?>
              <?php endif; ?>

              
              <tr class="<?php echo e($expired ? 'table-danger' : ''); ?>">
                <td><?php echo e($products->firstItem() + $index); ?></td>
                <td><?php echo e($p->product_name); ?></td>
                <td><?php echo e($p->serial_no); ?></td>
                <td><?php echo e($p->project_serial_no); ?></td>
                <td><?php echo e($p->warranty_end ? $end->format('d M Y') : '—'); ?></td>
                <td>
                  <?php if($p->warranty_end && $p->warranty_start): ?>
                    <?php
                      if ($expired) {
                          $badgeText = 'Expired';
                          $badgeClass = 'bg-danger text-white';
                          $tooltip = 'Expired on ' . $end->format('d M Y');
                      } else {
                          $totalMinutes = $now->diffInMinutes($end);
                          $totalDays = floor($totalMinutes / (60 * 24));
                          $remainingHours = floor(($totalMinutes % (60 * 24)) / 60);

                          $badgeText = "{$totalDays} days {$remainingHours} hours";
                          $tooltip = 'Ends on ' . $end->format('d M Y');

                          if ($totalDays <= 7) {
                              $badgeClass = 'bg-danger text-white';
                          } elseif ($totalDays <= 30) {
                              $badgeClass = 'bg-warning text-dark';
                          } else {
                              $badgeClass = 'bg-success text-white';
                          }
                      }
                    ?>

                    <span class="badge <?php echo e($badgeClass); ?>" data-bs-toggle="tooltip" title="<?php echo e($tooltip); ?>">
                      <?php echo e($badgeText); ?>

                    </span>
                  <?php else: ?>
                    <span class="text-muted">—</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="6" class="text-muted py-5 text-center">
                  <i class="fa fa-shield-alt fa-2x mb-3 text-danger"></i>
                  <h5 class="fw-bold">No warranty data found</h5>
                  <p class="small">Make sure products have warranty info assigned.</p>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      
      <?php if (isset($component)) { $__componentOriginal3e6684d352797b6b0d491487a3c7f550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e6684d352797b6b0d491487a3c7f550 = $attributes; } ?>
<?php $component = App\View\Components\PaginationBlock::resolve(['paginator' => $products] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PaginationBlock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $attributes = $__attributesOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $component = $__componentOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__componentOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
    </div>
  </div>
</div>


<?php $__env->startPush('scripts'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.forEach(function (tooltipTriggerEl) {
      new bootstrap.Tooltip(tooltipTriggerEl);
    });
  });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\warranties\index.blade.php ENDPATH**/ ?>