<?php $__env->startSection('title', 'Products in ' . $brand->brand_name); ?>

<?php $__env->startSection('contents'); ?>
<div class="row">
  <div class="col-lg-12">
    <div class="card">

      
      <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-3 px-4">
        <div class="d-flex align-items-center gap-3">
          <h3 class="mb-0 fw-bold">
            <i class="fa fa-industry me-2"></i> Products in <?php echo e($brand->brand_name); ?>

          </h3>
          <span class="badge bg-light text-dark fs-6 fw-semibold"><?php echo e($products->total()); ?> items</span>
        </div>
        <div class="d-flex flex-wrap gap-2 align-items-center">

          
          <form method="GET" action="<?php echo e(route('brands.products', $brand->id)); ?>" class="d-flex" style="max-width: 400px;">
            <div class="input-group">
              <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                class="form-control bg-light border-0 small" placeholder="Search by Serial Number" aria-label="Search">
              <button class="btn btn-info" type="submit">
                <i class="fas fa-search fa-sm"></i>
              </button>
            </div>
          </form>

          <?php if(auth()->user()->permission <= 1): ?>
            
            <a href="<?php echo e(route('products.create', ['brand_id' => $brand->id])); ?>"
               class="btn btn-success fw-semibold shadow-sm">
              <i class="fa fa-plus me-1"></i> Add Product
            </a>

            
            <a href="<?php echo e(route('products.export.brand', $brand->id)); ?>" class="btn btn-outline-success">
              📤 Export for <?php echo e($brand->brand_name); ?>

            </a>
          <?php endif; ?>

          
          <a href="<?php echo e(route('brands.index')); ?>"
             class="btn btn-warning fw-semibold shadow-sm text-white">
            <i class="fa fa-arrow-left me-1"></i> Back to Brands
          </a>
        </div>
      </div>

      
      <div class="card-body bg-light p-4">

        
        <?php if(Session::has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show shadow-sm fw-semibold" role="alert">
            <i class="fa fa-check-circle me-1"></i> <?php echo e(Session::get('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>

        
        <div class="table-responsive">
          <table class="table table-hover table-bordered align-middle text-center shadow-sm rounded"
            style="min-width: 1200px; border-radius: 0.5rem; overflow: hidden;">
            <thead style="background: linear-gradient(to right, #00C9FF, #92FE9D); color: white;">
              <tr class="text-uppercase fw-bold" style="height: 60px;">
                <th>SL</th>
                <th>Product</th>
                <th>Price</th>
                <th>Model</th>
                <th>Category</th>
                <th>Serial No</th>
                <th>Project Serial</th>
                <th>Location</th>
                <th>User Description</th>
                <th>Remarks</th>
                <th>Warranty</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="height: 55px; background-color: <?php echo e($loop->even ? '#f9f9f9' : '#ffffff'); ?>;">
                  <td class="fw-bold text-primary">
                    <?php echo e(($products->currentPage() - 1) * $products->perPage() + $loop->iteration); ?>

                  </td>
                  <td class="fw-semibold text-dark" title="<?php echo e($product->product_name); ?>">
                    <?php echo e($product->product_name); ?>

                  </td>
                  <td><?php echo e(number_format($product->price, 2)); ?> ৳</td>
                  <td title="<?php echo e($product->model->model_name ?? '-'); ?>">
                    <?php echo e($product->model->model_name ?? '-'); ?>

                  </td>
                  <td title="<?php echo e($product->category->category_name ?? '-'); ?>">
                    <?php echo e($product->category->category_name ?? '-'); ?>

                  </td>
                  <td title="<?php echo e($product->serial_no); ?>">
                    <?php echo e($product->serial_no); ?>

                  </td>
                  <td title="<?php echo e($product->project_serial ?? '-'); ?>">
                    <?php echo e($product->project_serial ?? '-'); ?>

                  </td>
                  <td title="<?php echo e($product->position ?? '-'); ?>">
                    <?php echo e($product->position ?? '-'); ?>

                  </td>
                  <td title="<?php echo e($product->user_description ?? '-'); ?>">
                    <?php echo e($product->user_description ?? '-'); ?>

                  </td>
                  <td title="<?php echo e($product->remarks ?? '-'); ?>">
                    <?php echo e($product->remarks ?? '-'); ?>

                  </td>
                  <td title="<?php echo e(strip_tags($product->warranty_countdown)); ?>">
                    <?php echo $product->warranty_countdown; ?>

                  </td>
                  <td>
                    <div class="d-flex justify-content-center gap-2">
                      <a href="<?php echo e(route('products.show', $product->id)); ?>"
                         class="btn btn-sm btn-outline-info" title="View">
                        <i class="fa fa-eye"></i>
                      </a>
                      <?php if(auth()->user()->permission <= 1): ?>
                        <a href="<?php echo e(route('products.edit', $product->id)); ?>"
                           class="btn btn-sm btn-outline-warning" title="Edit">
                          <i class="fa fa-edit"></i>
                        </a>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="12" class="text-center py-5 text-muted">
                    <div class="d-flex flex-column align-items-center justify-content-center">
                      <i class="fa fa-box-open fa-2x mb-3 text-danger"></i>
                      <h5 class="fw-bold">No products found for this brand</h5>
                      <p class="small">Try adding a new product under this brand to populate the list.</p>
                      <?php if(auth()->user()->permission <= 1): ?>
                        <a href="<?php echo e(route('products.create', ['brand_id' => $brand->id])); ?>"
                           class="btn btn-primary fw-bold mt-2 shadow-sm">
                          <i class="fa fa-plus me-1"></i> Add Product
                        </a>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        
        <?php if (isset($component)) { $__componentOriginal3e6684d352797b6b0d491487a3c7f550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e6684d352797b6b0d491487a3c7f550 = $attributes; } ?>
<?php $component = App\View\Components\PaginationBlock::resolve(['paginator' => $products] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PaginationBlock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $attributes = $__attributesOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $component = $__componentOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__componentOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\brands\products.blade.php ENDPATH**/ ?>