<?php $__env->startSection('title', 'Home Product'); ?>

<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card border-0 shadow-lg rounded-4 overflow-hidden">

            
                <div class="card-header text-white py-2" 
                    style="background: linear-gradient(90deg, #00bcd4, #2196f3); position: sticky; top: 0; z-index: 1020;">
                    <div class="row gy-2 align-items-center">

                        
                        <div class="col-12 col-md-3 d-flex align-items-center">
                            <h5 class="mb-0 fw-bold">
                                <i class="fa fa-boxes me-2"></i> Product Inventory
                            </h5>
                            <span class="badge bg-light text-dark ms-3">
                                <?php echo e($products->total()); ?> items
                            </span>
                        </div>

                        
                        <div class="col-12 col-md-3">
                            <form method="GET" action="<?php echo e(route('products.index')); ?>" 
                                class="d-flex justify-content-md-start justify-content-center">
                                <div class="input-group input-group-sm w-100" style="max-width: 320px;">
                                    <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                                        class="form-control bg-light border-0"
                                        placeholder="Search Product, Serial No, or Project Serial No"
                                        aria-label="Search">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </form>
                        </div>

                        
                        <div class="col-12 col-md-6 text-md-end">
                            <?php if(auth()->user()->permission <= 1): ?>
                                <div class="d-flex flex-wrap justify-content-md-end justify-content-center gap-2">

                                    <a href="<?php echo e(route('products.sample')); ?>" 
                                    class="btn btn-sm btn-secondary shadow-sm">
                                        <i class="fa fa-file-csv me-1"></i> Sample CSV
                                    </a>

                                    <form action="<?php echo e(route('products.import')); ?>" method="POST" 
                                        enctype="multipart/form-data" 
                                        class="d-flex align-items-center gap-2">
                                        <?php echo csrf_field(); ?>
                                        <input type="file" name="file" 
                                            class="form-control form-control-sm" 
                                            style="max-width: 140px;" required>
                                        <button type="submit" class="btn btn-sm btn-primary shadow-sm">
                                            <i class="fa fa-file-import me-1"></i> Import
                                        </button>
                                    </form>

                                    <a href="<?php echo e(route('products.export.excel')); ?>" 
                                    class="btn btn-sm btn-success shadow-sm">
                                        <i class="fa fa-file-export me-1"></i> Export All
                                    </a>

                                    <a href="<?php echo e(route('products.create')); ?>" 
                                    class="btn btn-sm btn-warning fw-bold shadow-sm">
                                        <i class="fa fa-plus me-1"></i> Add Product
                                    </a>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            
            <?php if(Session::has('skippedRows') && count(Session::get('skippedRows')) > 0): ?>
                <div class="alert alert-warning alert-dismissible fade show shadow-sm fw-semibold" role="alert">
                    <i class="fa fa-exclamation-triangle me-1"></i>
                    Some rows were skipped during import:

                    <div class="table-responsive mt-2">
                        <table class="table table-sm table-bordered table-striped mb-0 small">
                            <thead class="table-light">
                                <tr>
                                    <th>Reason</th>
                                    <th>Product Name</th>
                                    <th>Serial No</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = Session::get('skippedRows'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row['skip_reason'] ?? 'Unknown'); ?></td>
                                        <td><?php echo e($row['product_name'] ?? 'N/A'); ?></td>
                                        <td><?php echo e($row['serial_no'] ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <a href="<?php echo e(route('products.skipped.export')); ?>" class="btn btn-sm btn-outline-dark mt-2">
                        <i class="fa fa-download"></i> Download Skipped Rows CSV
                    </a>

                    
                    <form action="<?php echo e(route('products.skipped.clear')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-close" aria-label="Close"></button>
                    </form>
                </div>
            <?php endif; ?>

            
            <div class="card-body bg-light p-4">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show shadow-sm fw-semibold" role="alert">
                        <i class="fa fa-check-circle me-1"></i> <?php echo e(Session::get('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show shadow-sm fw-semibold" role="alert">
                        <i class="fa fa-exclamation-circle me-1"></i> <?php echo e(Session::get('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle text-center shadow-sm product-table">
                        <thead class="text-uppercase fw-bold text-primary" style="background-color: #e3f2fd;">
                            <tr>
                                <th style="width: 50px;">SL</th>
                                <th style="min-width: 80px;">Product</th>
                                
                                <th style="min-width: 90px;">Serial No</th>
                                <th class="d-none-xs" style="min-width: 80px;">Project Serial</th>
                                <th class="d-none-xs" style="min-width: 70px;">Location</th>
                                <th class="d-none-md" style="min-width: 100px;">User Description</th>
                                <th class="d-none-sm" style="min-width: 80px;">Remarks</th>
                                <th style="min-width: 90px;">Warranty</th>
                                <th style="min-width: 120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="SL" class="fw-bold text-primary">
                                    <?php echo e(($products->currentPage() - 1) * $products->perPage() + $loop->iteration); ?>

                                </td>

                                <td data-label="Product" class="fw-semibold text-dark text-truncate tooltip-cell" title="<?php echo e($p->product_name); ?>">
                                    <?php if(request('search')): ?>
                                        <?php echo str_replace(request('search'), '<mark>' . e(request('search')) . '</mark>', e($p->product_name)); ?>

                                    <?php else: ?>
                                        <?php echo e($p->product_name); ?>

                                    <?php endif; ?>
                                </td>

                                

                                <td data-label="Serial No" class="tooltip-cell text-truncate" title="<?php echo e($p->serial_no); ?>">
                                    <?php if(request('search')): ?>
                                        <?php echo str_replace(request('search'), '<mark>' . e(request('search')) . '</mark>', e($p->serial_no)); ?>

                                    <?php else: ?>
                                        <?php echo e($p->serial_no ?? '-'); ?>

                                    <?php endif; ?>
                                </td>

                                <td data-label="Project Serial" class="d-none-xs tooltip-cell text-truncate" title="<?php echo e($p->project_serial_no); ?>">
                                    <?php if(request('search')): ?>
                                        <?php echo str_replace(request('search'), '<mark>' . e(request('search')) . '</mark>', e($p->project_serial_no)); ?>

                                    <?php else: ?>
                                        <?php echo e($p->project_serial_no ?? '-'); ?>

                                    <?php endif; ?>
                                </td>

                                <td data-label="Location" class="d-none-xs tooltip-cell text-truncate" title="<?php echo e($p->position); ?>">
                                    <?php echo e($p->position ?? '-'); ?>

                                </td>

                                <td data-label="User Description" class="d-none-md tooltip-cell text-truncate" title="<?php echo e($p->user_description); ?>">
                                    <?php echo e($p->user_description ?? '-'); ?>

                                </td>

                                <td data-label="Remarks" class="d-none-sm tooltip-cell text-truncate" title="<?php echo e($p->remarks); ?>">
                                    <?php echo e($p->remarks ?? '-'); ?>

                                </td>

                                <td data-label="Warranty"><?php echo $p->warranty_countdown; ?></td>

                                <td data-label="Actions">
                                    <div class="d-flex flex-wrap gap-1 justify-content-center justify-content-md-start">
                                        <a href="<?php echo e(route('products.show', $p->id)); ?>" 
                                        class="btn btn-sm btn-outline-info" title="View">
                                            <i class="fa fa-eye"></i>
                                        </a>

                                        <?php if(auth()->user()->permission <= 1): ?>
                                            <a href="<?php echo e(route('products.edit', $p->id)); ?>" 
                                            class="btn btn-sm btn-outline-warning" title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>

                                            <form action="<?php echo e(route('products.destroy', $p->id)); ?>" 
                                                method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" 
                                                        class="btn btn-sm btn-outline-danger" 
                                                        title="Delete">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>

                                            <a href="<?php echo e(route('maintenance.create', ['product_id' => $p->id])); ?>" 
                                            class="btn btn-sm btn-outline-primary" title="Send to Maintenance">
                                                <i class="fa fa-tools me-1"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="12" class="text-center py-5 text-muted">
                                    <div class="d-flex flex-column align-items-center justify-content-center">
                                        <img src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png" alt="No products" width="100" class="mb-3 opacity-75">
                                        <h5 class="fw-bold text-danger">No products found</h5>
                                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-outline-primary btn-lg fw-bold">
                                            <i class="fa fa-plus me-1"></i> Add Product
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if (isset($component)) { $__componentOriginal3e6684d352797b6b0d491487a3c7f550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e6684d352797b6b0d491487a3c7f550 = $attributes; } ?>
<?php $component = App\View\Components\PaginationBlock::resolve(['paginator' => $products] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PaginationBlock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $attributes = $__attributesOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $component = $__componentOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__componentOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>

                <!-- Recycle Bin Section -->
                <?php if(\App\Models\Product::onlyTrashed()->count() > 0): ?>
                <div class="mt-4">
                    <h5 class="text-danger">🗑️ Recycle Bin</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered product-table">
                            <thead class="bg-light">
                                <tr>
                                    <th>Product Name</th>
                                    <th>Serial No</th>
                                    <th class="d-none-sm">Deleted At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = \App\Models\Product::onlyTrashed()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="tooltip-cell" title="<?php echo e($deleted->product_name); ?>">
                                        <?php echo e(Str::limit($deleted->product_name, 15, '...')); ?>

                                    </td>
                                    <td><?php echo e($deleted->serial_no); ?></td>
                                    <td class="d-none-sm"><?php echo e($deleted->deleted_at->format('d M Y, h:i A')); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('products.restore', $deleted->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-success" title="Restore Product">
                                                <i class="fa fa-undo"></i> Restore
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('products.forceDelete', $deleted->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-danger" title="Permanently Delete">
                                                <i class="fa fa-trash"></i> Delete Permanently
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
    /* Compact text for all tables */
    .product-table {
        font-size: 0.8rem;
    }

    .product-table td,
    .product-table th {
        padding-left: 0.5rem; /* reduce left gap */
        text-align: left;     /* align everything left */
    }

    .table-responsive {
        overflow-x: auto;
    }

    /* Mobile card layout */
    @media (max-width: 767px) {
        .product-table,
        .product-table thead,
        .product-table tbody,
        .product-table th,
        .product-table td,
        .product-table tr {
            display: block;
            width: 100%;
        }

        .product-table thead {
            display: none; /* hide header on mobile */
        }

        .product-table tr {
            margin-bottom: 1rem;
            border: 1px solid #dee2e6;
            border-radius: 0.5rem;
            background: #fff;
            padding: 0.5rem;
            text-align: left;
        }

        .product-table td {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            padding: 0.4rem 0.6rem;
            border: none;
            font-size: 0.85rem;
        }

        .product-table td::before {
            content: attr(data-label);
            flex: 0 0 40%;
            font-weight: 600;
            color: #007bff;
            text-align: left;
            margin-right: 0.5rem;
        }
    }
</style>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/products/index.blade.php ENDPATH**/ ?>