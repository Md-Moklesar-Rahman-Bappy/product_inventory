<ul class="navbar-nav sidebar sidebar-dark accordion bg-gradient-primary" id="accordionSidebar">

    
    <a class="sidebar-brand d-flex align-items-center justify-content-center py-3" href="<?php echo e(route('dashboard')); ?>">
        <div class="sidebar-brand-icon rotate-n-15 text-warning">
            <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="SOCDS Logo" style="height: 50px">
        </div>
        <div class="sidebar-brand-text mx-3 text-white">
            Product Inventory System
        </div>
    </a>

    <hr class="sidebar-divider my-0">

    
    <li class="nav-item <?php echo e(request()->routeIs('dashboard') ? 'active bg-gradient-info shadow-sm' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>" data-toggle="tooltip" title="Dashboard">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

    
    <li class="nav-item <?php echo e(request()->routeIs('activity.logs') ? 'active bg-gradient-info shadow-sm' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('activity.logs')); ?>" data-toggle="tooltip" title="Activity Logs">
            <i class="fas fa-clipboard-list"></i>
            <span>Activity Logs</span>
        </a>
    </li>

    <hr class="sidebar-divider">

    
    <li class="nav-item">
        <a class="nav-link collapsed <?php echo e(request()->routeIs('categories.*', 'brands.*', 'models.*') ? 'active' : ''); ?>" href="#" data-toggle="collapse" data-target="#collapseCategory"
            aria-expanded="<?php echo e(request()->routeIs('categories.*', 'brands.*', 'models.*') ? 'true' : 'false'); ?>" aria-controls="collapseCategory">
            <i class="fas fa-tags"></i>
            <span>Add Items</span>
        </a>
        <div id="collapseCategory" class="collapse <?php echo e(request()->routeIs('categories.*', 'brands.*', 'models.*') ? 'show' : ''); ?>" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('categories.index')); ?>">
                    <i class="fas fa-eye text-primary me-1"></i> Categories</a>
                <a class="collapse-item" href="<?php echo e(route('brands.index')); ?>">
                    <i class="fas fa-eye text-primary me-1"></i> Brands</a>
                <a class="collapse-item" href="<?php echo e(route('models.index')); ?>">
                    <i class="fas fa-eye text-primary me-1"></i> Models</a>
            </div>
        </div>
    </li>

    
    <li class="nav-item">
        <a class="nav-link collapsed <?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>" href="#" data-toggle="collapse" data-target="#collapseProduct"
            aria-expanded="<?php echo e(request()->routeIs('products.*') ? 'true' : 'false'); ?>" aria-controls="collapseProduct">
            <i class="fas fa-box-open"></i>
            <span>Product</span>
        </a>
        <div id="collapseProduct" class="collapse <?php echo e(request()->routeIs('products.*') ? 'show' : ''); ?>" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('products.index')); ?>">
                    <i class="fas fa-eye text-primary me-1"></i> Products</a>
                <a class="collapse-item" href="<?php echo e(route('products.create')); ?>">
                    <i class="fas fa-plus text-success me-1"></i> Add Product</a>
            </div>
        </div>
    </li>

    
    <li class="nav-item">
        <a class="nav-link collapsed <?php echo e(request()->routeIs('maintenance.*') ? 'active' : ''); ?>" href="#" data-toggle="collapse" data-target="#collapseMaintenance"
            aria-expanded="<?php echo e(request()->routeIs('maintenance.*') ? 'true' : 'false'); ?>" aria-controls="collapseMaintenance">
            <i class="fas fa-tools"></i>
            <span>Maintenance</span>
        </a>
        <div id="collapseMaintenance" class="collapse <?php echo e(request()->routeIs('maintenance.*') ? 'show' : ''); ?>" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('maintenance.index')); ?>">
                    <i class="fas fa-eye text-primary me-1"></i> Maintenance Logs</a>
                <a class="collapse-item" href="<?php echo e(route('maintenance.create')); ?>">
                    <i class="fas fa-plus text-success me-1"></i> Add Maintenance</a>
            </div>
        </div>
    </li>

    
    <li class="nav-item">
        <a class="nav-link collapsed <?php echo e(request()->routeIs('warranties.*') ? 'active' : ''); ?>" href="#" data-toggle="collapse" data-target="#collapseWarranty"
            aria-expanded="<?php echo e(request()->routeIs('warranties.*') ? 'true' : 'false'); ?>" aria-controls="collapseWarranty">
            <i class="fas fa-shield-alt"></i>
            <span>Warranty</span>
        </a>
        <div id="collapseWarranty" class="collapse <?php echo e(request()->routeIs('warranties.*') ? 'show' : ''); ?>" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('warranties.index')); ?>">
                    <i class="fas fa-eye text-primary me-1"></i> Warranty Status</a>
            </div>
        </div>
    </li>

    <?php if(auth()->user()->isSuperadmin()): ?>
    
    <li class="nav-item <?php echo e(request()->routeIs('users.index') ? 'active bg-gradient-info shadow-sm' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('users.index')); ?>" data-toggle="tooltip" title="User">
            <i class="fas fa-user"></i>
            <span>User</span>
        </a>
    </li>
    <?php endif; ?>

    
    <li class="nav-item <?php echo e(request()->routeIs('users.show') ? 'active bg-gradient-info shadow-sm' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('users.show', auth()->user()->id)); ?>" data-toggle="tooltip" title="Profile">
            <i class="fas fa-user-circle"></i>
            <span>Profile</span>
        </a>
    </li>

    <hr class="sidebar-divider d-none d-md-block">

    
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>


<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
<?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\layouts\sidebar.blade.php ENDPATH**/ ?>