<?php $__env->startSection('title', 'Maintenance Records'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container py-5">
  <div class="card border-0 shadow-lg rounded-4">
    <div class="card-header bg-info text-white py-3">
      <h3 class="mb-0 fw-bold">
        <i class="fa fa-tools me-2"></i> Maintenance History
        <span class="badge bg-light text-dark ms-3"><?php echo e($maintenances->total()); ?></span>
      </h3>
    </div>

    <div class="card-body bg-light px-4 py-5">
      <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm fw-semibold" role="alert">
          <i class="fa fa-check-circle me-1"></i> <?php echo e(Session::get('success')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center shadow-sm">
          <thead class="bg-light text-uppercase fw-bold text-primary">
            <tr>
              <th>SL</th>
              <th>Product</th>
              <th>Serial No</th>
              <th>Issue</th>
              <th>Start</th>
              <th>End</th>
              <th>Status</th>
              <th>Warranty</th>
              <th>Logged By</th>
              <th style="min-width: 140px;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($maintenances->firstItem() + $index); ?></td>
                <td><?php echo e($m->product->product_name); ?></td>
                <td><?php echo e($m->product->serial_no); ?></td>
                <td><?php echo e(Str::limit($m->description, 40)); ?></td>
                <td><?php echo e($m->start_time->format('d M Y, h:i A')); ?></td>
                <td><?php echo e($m->end_time->format('d M Y, h:i A')); ?></td>
                <td>
                  <?php if(now()->between($m->start_time, $m->end_time)): ?>
                    <span class="badge bg-warning text-dark">In Progress</span>
                  <?php elseif(now()->lt($m->start_time)): ?>
                    <span class="badge bg-info text-dark">Scheduled</span>
                  <?php else: ?>
                    <span class="badge bg-success">Completed</span>
                  <?php endif; ?>
                </td>
                <td><?php echo $m->product->warranty_countdown; ?></td>
                <td><?php echo e($m->user->name ?? 'System'); ?></td>
                <td>
                  <div class="d-flex justify-content-center gap-2">
                    <a href="<?php echo e(route('maintenance.show', $m->id)); ?>" class="btn btn-sm btn-outline-info" title="View">
                      <i class="fa fa-eye"></i>
                    </a>
                    <?php if(auth()->user()->permission <= 1): ?>
                      <a href="<?php echo e(route('maintenance.edit', $m->id)); ?>" class="btn btn-sm btn-outline-warning" title="Edit">
                        <i class="fa fa-edit"></i>
                      </a>
                      <form action="<?php echo e(route('maintenance.destroy', $m->id)); ?>" method="POST" onsubmit="return confirm('Delete this record?')" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                          <i class="fa fa-trash"></i>
                        </button>
                      </form>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="10" class="text-center py-5 text-muted">
                  <i class="fa fa-tools fa-2x mb-3 text-danger"></i>
                  <h5 class="fw-bold">No maintenance records found</h5>
                  <p class="small">Start by logging a maintenance entry for a product.</p>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      
      <div class="mt-4">
        <?php if (isset($component)) { $__componentOriginal3e6684d352797b6b0d491487a3c7f550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e6684d352797b6b0d491487a3c7f550 = $attributes; } ?>
<?php $component = App\View\Components\PaginationBlock::resolve(['paginator' => $maintenances] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PaginationBlock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $attributes = $__attributesOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $component = $__componentOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__componentOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
      </div>

      
      <?php if(auth()->user()->permission <= 1 && $trashedMaintenances->total() > 0): ?>
        <div class="mt-5">
          <h5 class="text-danger fw-bold"><i class="fa fa-trash-alt me-2"></i> Archived Maintenance</h5>
          <table class="table table-bordered table-hover text-center shadow-sm">
            <thead class="bg-light">
              <tr>
                <th>Product</th>
                <th>Serial No</th>
                <th>Issue</th>
                <th>Deleted At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $trashedMaintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archived): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-danger">
                  <td><?php echo e($archived->product->product_name); ?></td>
                  <td><?php echo e($archived->product->serial_no); ?></td>
                  <td><?php echo e(Str::limit($archived->description, 40)); ?></td>
                  <td><?php echo e($archived->deleted_at->format('d M Y, h:i A')); ?></td>
                  <td>
                    <form action="<?php echo e(route('maintenance.restore', $archived->id)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <button class="btn btn-sm btn-success fw-bold" title="Restore Maintenance">
                        <i class="fa fa-undo"></i> Restore
                      </button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php if (isset($component)) { $__componentOriginal3e6684d352797b6b0d491487a3c7f550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e6684d352797b6b0d491487a3c7f550 = $attributes; } ?>
<?php $component = App\View\Components\PaginationBlock::resolve(['paginator' => $trashedMaintenances] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PaginationBlock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $attributes = $__attributesOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $component = $__componentOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__componentOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\maintenance\index.blade.php ENDPATH**/ ?>