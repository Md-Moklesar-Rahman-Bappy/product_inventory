<?php if($paginator->hasPages()): ?>
    <nav class="d-flex flex-column align-items-center gap-3 mt-4" aria-label="Pagination Navigation">

        
        <div class="d-sm-none">
            <ul class="pagination pagination-sm mb-0">
                
                <li class="page-item <?php echo e($paginator->onFirstPage() ? 'disabled' : ''); ?>">
                    <?php if($paginator->onFirstPage()): ?>
                        <span class="page-link rounded-pill shadow-sm px-3 py-1" aria-hidden="true">
                            <i class="fa fa-angle-left me-1"></i> Previous
                        </span>
                    <?php else: ?>
                        <a class="page-link rounded-pill shadow-sm px-3 py-1" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">
                            <i class="fa fa-angle-left me-1"></i> Previous
                        </a>
                    <?php endif; ?>
                </li>

                
                <li class="page-item <?php echo e($paginator->hasMorePages() ? '' : 'disabled'); ?>">
                    <?php if($paginator->hasMorePages()): ?>
                        <a class="page-link rounded-pill shadow-sm px-3 py-1" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">
                            Next <i class="fa fa-angle-right ms-1"></i>
                        </a>
                    <?php else: ?>
                        <span class="page-link rounded-pill shadow-sm px-3 py-1" aria-hidden="true">
                            Next <i class="fa fa-angle-right ms-1"></i>
                        </span>
                    <?php endif; ?>
                </li>
            </ul>
        </div>

        
        <div>
            <span class="badge bg-light text-dark shadow-sm px-3 py-2 rounded-pill">
                Showing <strong><?php echo e($paginator->firstItem()); ?></strong>
                to <strong><?php echo e($paginator->lastItem()); ?></strong>
                of <strong><?php echo e($paginator->total()); ?></strong> results
            </span>
        </div>

        
        <div class="d-none d-sm-flex justify-content-center">
            <ul class="pagination pagination-sm mb-0">
                
                <li class="page-item <?php echo e($paginator->onFirstPage() ? 'disabled' : ''); ?>">
                    <?php if($paginator->onFirstPage()): ?>
                        <span class="page-link rounded-pill shadow-sm px-3 py-1" aria-hidden="true">&lsaquo;</span>
                    <?php else: ?>
                        <a class="page-link rounded-pill shadow-sm px-3 py-1" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&lsaquo;</a>
                    <?php endif; ?>
                </li>

                
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_string($element)): ?>
                        <li class="page-item disabled"><span class="page-link"><?php echo e($element); ?></span></li>
                    <?php endif; ?>

                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="page-item <?php echo e($page == $paginator->currentPage() ? 'active' : ''); ?>">
                                <?php if($page == $paginator->currentPage()): ?>
                                    <span class="page-link rounded-pill shadow-sm px-3 py-1" aria-current="page"><?php echo e($page); ?></span>
                                <?php else: ?>
                                    <a class="page-link rounded-pill shadow-sm px-3 py-1" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <li class="page-item <?php echo e($paginator->hasMorePages() ? '' : 'disabled'); ?>">
                    <?php if($paginator->hasMorePages()): ?>
                        <a class="page-link rounded-pill shadow-sm px-3 py-1" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">&rsaquo;</a>
                    <?php else: ?>
                        <span class="page-link rounded-pill shadow-sm px-3 py-1" aria-hidden="true">&rsaquo;</span>
                    <?php endif; ?>
                </li>
            </ul>
        </div>

        
        <div class="text-muted small">
            <i class="fa fa-file-alt me-1"></i>
            Page <?php echo e($paginator->currentPage()); ?> of <?php echo e($paginator->lastPage()); ?>

        </div>

        
        <form method="GET" action="<?php echo e(request()->url()); ?>" class="d-inline-flex align-items-center gap-2">
            <?php if(request('search')): ?>
                <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
            <?php endif; ?>

            <label for="per_page" class="fw-semibold text-muted mb-0">Show:</label>
            <select name="per_page" id="per_page" class="form-select form-select-sm w-auto shadow-sm rounded-pill"
                onchange="this.form.submit()">
                <?php $__currentLoopData = [10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($size); ?>" <?php echo e(request('per_page', 10) == $size ? 'selected' : ''); ?>>
                        <?php echo e($size); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <span class="text-muted">per page</span>
        </form>

    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\vendor\pagination\bootstrap-5.blade.php ENDPATH**/ ?>