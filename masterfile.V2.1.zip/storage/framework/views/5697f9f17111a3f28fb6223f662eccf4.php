<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container py-4">
  <div class="card shadow-sm">
    <div class="card-header bg-warning text-dark">
      <h4 class="mb-0"><i class="fa fa-edit me-2"></i> Edit Product</h4>
    </div>

    <div class="card-body">
      
      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <strong>Validation Error:</strong>
          <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <h5 class="text-secondary mb-3">📦 Product Info</h5>

        <div class="row mb-3">
          <div class="col-md-6">
            <label class="form-label">Product Name</label>
            <input type="text" name="product_name" class="form-control"
              value="<?php echo e(old('product_name', $product->product_name)); ?>" required>
            <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-6">
            <label class="form-label">Price (৳)</label>
            <input type="number" name="price" class="form-control"
              value="<?php echo e(old('price', $product->price)); ?>" step="0.01" min="0" required>
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            
            <?php if($product->price > 100000): ?>
              <span class="badge bg-danger text-light mt-2">💸 High Value</span>
            <?php elseif($product->price < 5000): ?>
              <span class="badge bg-success mt-2">🔖 Budget Pick</span>
            <?php endif; ?>
          </div>
        </div>

        
        <div class="row mb-3">
          <div class="col-md-4">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-control" required>
              <option value="">Select Category</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>" <?php echo e(old('category_id', $product->category_id) == $c->id ? 'selected' : ''); ?>>
                  <?php echo e($c->category_name); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Brand</label>
            <select name="brand_id" class="form-control" required>
              <option value="">Select Brand</option>
              <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($b->id); ?>" <?php echo e(old('brand_id', $product->brand_id) == $b->id ? 'selected' : ''); ?>>
                  <?php echo e($b->brand_name); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Model</label>
            <select name="model_id" class="form-control" required>
              <option value="">Select Model</option>
              <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($m->id); ?>" <?php echo e(old('model_id', $product->model_id) == $m->id ? 'selected' : ''); ?>>
                  <?php echo e($m->model_name); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['model_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        
        <h5 class="text-secondary mb-3">🔢 Serial Numbers</h5>
        <div class="row mb-3">
          <div class="col-md-6">
            <label class="form-label">Serial No</label>
            <input type="text" name="serial_no" class="form-control"
              value="<?php echo e(old('serial_no', $product->serial_no)); ?>">
            <?php $__errorArgs = ['serial_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-6">
            <label class="form-label">Project Serial No</label>
            <input type="text" name="project_serial_no" class="form-control"
              value="<?php echo e(old('project_serial_no', $product->project_serial_no)); ?>">
            <?php $__errorArgs = ['project_serial_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        
        <h5 class="text-secondary mb-3">📍 Location & Description</h5>
        <div class="row mb-3">
          <div class="col-md-6">
            <label class="form-label">Location</label>
            <input type="text" name="position" class="form-control"
              value="<?php echo e(old('position', $product->position)); ?>">
            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-6">
            <label class="form-label">User Description</label>
            <textarea name="user_description" class="form-control" rows="3"><?php echo e(old('user_description', $product->user_description)); ?></textarea>
            <?php $__errorArgs = ['user_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        
        <h5 class="text-secondary mb-3">📝 Remarks</h5>
        <div class="mb-3">
          <label class="form-label">Remarks</label>
          <input type="text" name="remarks" class="form-control"
            value="<?php echo e(old('remarks', $product->remarks)); ?>">
          <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        
        
        <h5 class="text-secondary mb-3">🛡️ Warranty Period</h5>
        <div class="row mb-3">
        <div class="col-md-6">
            <label for="warranty_start" class="form-label">Warranty Start</label>
            <input type="date" id="warranty_start" name="warranty_start"
                class="form-control shadow-sm <?php $__errorArgs = ['warranty_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                value="<?php echo e(old('warranty_start', $product->warranty_start?->format('Y-m-d'))); ?>">
            <?php $__errorArgs = ['warranty_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label for="warranty_end" class="form-label">Warranty End</label>
            <input type="date" id="warranty_end" name="warranty_end"
                class="form-control shadow-sm <?php $__errorArgs = ['warranty_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                value="<?php echo e(old('warranty_end', $product->warranty_end?->format('Y-m-d'))); ?>">
            <?php $__errorArgs = ['warranty_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        </div>

        
        <?php if($product->warranty_end): ?>
          <div class="mb-3">
            <strong>Status:</strong> <?php echo $product->warranty_countdown; ?>

          </div>
        <?php endif; ?>

        
        <div class="d-flex justify-content-between mt-4">
          <button class="btn btn-warning">
            <i class="fa fa-save me-1"></i> Update
          </button>
          <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">
            <i class="fa fa-arrow-left me-1"></i> Cancel
          </a>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/products/edit.blade.php ENDPATH**/ ?>