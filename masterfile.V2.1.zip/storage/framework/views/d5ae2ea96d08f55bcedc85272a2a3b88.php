<?php $__env->startSection('title', 'Home Category'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container py-5">
  
  <div class="card border-0 shadow-lg rounded-4 overflow-hidden">

    
    <div class="card-header text-white d-flex justify-content-between align-items-center" style="background: linear-gradient(90deg, #00C9FF, #92FE9D); padding: 1.5rem;">
      <h3 class="mb-0 fw-bold">
        <i class="fa fa-list-alt me-2"></i> Category List
        <span class="badge bg-light text-dark ms-3"><?php echo e($categories->total()); ?></span>
      </h3>
      <?php if(auth()->user()->permission <= 1): ?>
        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-lg fw-bold shadow-sm" style="background: linear-gradient(to right, #FF512F, #DD2476); color: white;">
          <i class="fa fa-plus me-1"></i> Add Category
        </a>
      <?php endif; ?>
    </div>

    
    <div class="card-body bg-light" style="padding: 2rem;">

      
      <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm fw-semibold" role="alert">
          <i class="fa fa-check-circle me-1"></i> <?php echo e(Session::get('success')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endif; ?>

      
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center shadow-sm" style="min-width: 800px;">
          <thead style="background: linear-gradient(to right, #FFB75E, #ED8F03); color: white;">
            <tr style="height: 60px;">
              <th style="width: 80px;">SL</th>
              <th style="min-width: 200px;">Category</th>
              <th style="min-width: 220px;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr style="height: 55px;" <?php if($c->trashed()): ?> class="table-danger" <?php endif; ?>>
                <td class="fw-bold text-primary"><?php echo e($loop->iteration); ?></td>
                <td class="fw-semibold">
                  <a href="<?php echo e(route('categories.products', $c->id)); ?>"
                     class="text-decoration-none text-dark fw-semibold"
                     style="transition: color 0.2s;"
                     onmouseover="this.style.color='#0d6efd'"
                     onmouseout="this.style.color=''"
                     title="View products under <?php echo e($c->category_name); ?>">
                    <?php echo e($c->category_name); ?>

                  </a>
                  <?php if($c->trashed()): ?>
                    <span class="badge bg-danger ms-2">Archived</span>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if(auth()->user()->permission <= 1): ?>
                    <div class="action-buttons">
                      <?php if($c->trashed()): ?>
                        <form action="<?php echo e(route('categories.restore', $c->id)); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <button type="submit" class="btn btn-sm btn-outline-success" title="Restore">
                            <i class="fa fa-undo"></i>
                          </button>
                        </form>
                      <?php else: ?>
                        <a href="<?php echo e(route('categories.edit', $c->id)); ?>" class="btn btn-sm btn-outline-warning" title="Edit">
                          <i class="fa fa-edit"></i>
                        </a>
                        <form action="<?php echo e(route('categories.destroy', $c->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to archive this category?')" style="display:inline;">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button type="submit" class="btn btn-sm btn-outline-danger" title="Archive">
                            <i class="fa fa-trash"></i>
                          </button>
                        </form>
                      <?php endif; ?>
                    </div>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="3" class="text-center py-5 text-muted">
                  <div class="d-flex flex-column align-items-center justify-content-center">
                    <img src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png" alt="No categories" width="100" class="mb-3 opacity-75">
                    <h5 class="fw-bold text-danger">No categories found</h5>
                    <p class="small">Start by adding a new category to your list.</p>
                    <?php if(auth()->user()->permission <= 1): ?>
                      <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-lg fw-bold" style="background: linear-gradient(to right, #FF512F, #DD2476); color: white;">
                        <i class="fa fa-plus me-1"></i> Add Category
                      </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <?php if (isset($component)) { $__componentOriginal3e6684d352797b6b0d491487a3c7f550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e6684d352797b6b0d491487a3c7f550 = $attributes; } ?>
<?php $component = App\View\Components\PaginationBlock::resolve(['paginator' => $categories] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PaginationBlock::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $attributes = $__attributesOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__attributesOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e6684d352797b6b0d491487a3c7f550)): ?>
<?php $component = $__componentOriginal3e6684d352797b6b0d491487a3c7f550; ?>
<?php unset($__componentOriginal3e6684d352797b6b0d491487a3c7f550); ?>
<?php endif; ?>

      <!-- Recycle Bin Section -->
      <?php if(auth()->user()->permission <= 1 && \App\Models\Category::onlyTrashed()->count() > 0 && !request()->has('show_trashed')): ?>
        <div class="mt-5">
          <h5 class="text-danger fw-bold"><i class="fa fa-trash-alt me-2"></i> Recycle Bin</h5>
          <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle text-center shadow-sm" style="min-width: 800px;">
              <thead class="bg-light">
                <tr>
                  <th>Category Name</th>
                  <th>Deleted At</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = \App\Models\Category::onlyTrashed()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="table-danger">
                    <td class="fw-semibold">
                      <?php echo e($deleted->category_name); ?>

                      <span class="badge bg-danger text-white ms-2">Archived</span>
                    </td>
                    <td><?php echo e($deleted->deleted_at->format('d M Y, h:i A')); ?></td>
                    <td>
                      <form action="<?php echo e(route('categories.restore', $deleted->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-success" title="Restore Category">
                          <i class="fa fa-undo"></i> Restore
                        </button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views\categories\index.blade.php ENDPATH**/ ?>