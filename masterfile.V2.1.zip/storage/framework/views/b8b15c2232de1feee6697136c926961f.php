<?php if($paginator->hasPages()): ?>
    <nav class="pagination-block mt-4" aria-label="Pagination Navigation">
        <ul class="pagination justify-content-center flex-wrap gap-2">

            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">&laquo;&laquo;</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url(1)); ?>" rel="first">&laquo;&laquo;</a></li>
            <?php endif; ?>

            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">&laquo;</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&laquo;</a></li>
            <?php endif; ?>

            
            <?php
                $current = $paginator->currentPage();
                $last = $paginator->lastPage();
                $start = max($current - 2, 1);
                $end = min($start + 4, $last);
                if ($end - $start < 4) {
                    $start = max($end - 4, 1);
                }
            ?>

            <?php for($page = $start; $page <= $end; $page++): ?>
                <?php if($page == $current): ?>
                    <li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($page); ?></span></li>
                <?php else: ?>
                    <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($page)); ?>"><?php echo e($page); ?></a></li>
                <?php endif; ?>
            <?php endfor; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">&raquo;</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">&raquo;</span></li>
            <?php endif; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($last)); ?>" rel="last">&raquo;&raquo;</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">&raquo;&raquo;</span></li>
            <?php endif; ?>

        </ul>
    </nav>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\product_inventory\resources\views/components/pagination-block.blade.php ENDPATH**/ ?>